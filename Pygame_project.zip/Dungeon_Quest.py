import os
import sys
import pygame
import pygame_gui

pygame.init()

all_sprites = pygame.sprite.Group()
walls = pygame.sprite.Group()
floors = pygame.sprite.Group()
mag_stones = pygame.sprite.Group()
destinations = pygame.sprite.Group()
invisibles = pygame.sprite.Group()
hero_sprite = pygame.sprite.Group()

x = 50
y = 50
speed = 50
TILE_SIZE = 50
width, height = 1920, 1080
SIZE = width, height

clock = pygame.time.Clock()
screen = pygame.display.set_mode(SIZE)
pygame.display.set_caption('Dungeon quest')


map_of_level = 'map1.txt'


def load_image(name, color_key=None):
    fullname = os.path.join('data1', name)
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    if color_key is not None:
        image = image.convert()
        if color_key == -1:
            color_key = image.get_at((0, 0))
        image.set_colorkey(color_key)
    else:
        image = image.convert_alpha()
    return image


icon = load_image('icon.png')
pygame.display.set_icon(icon)
game_bg = load_image('game_bg.jpg')
menu_bg = load_image('menu_bg.png')


class Level_construct:
    def __init__(self, level_name):
        self.lvl = []
        self.fullname = os.path.join('data1', level_name)
        with open(self.fullname) as input_file:
            for line in input_file:
                self.lvl.append(list(map(int, line.split())))
        self.height = len(self.lvl)
        self.width = len(self.lvl[0])

    def map_return(self):
        return self.lvl


class Wall(pygame.sprite.Sprite):

    def __init__(self, pos_w):
        super().__init__(all_sprites)
        self.add(walls)
        self.image = load_image('wall.png')
        self.rect = self.image.get_rect()
        self.rect.x = pos_w[0]
        self.rect.y = pos_w[1]


class Invisibles_wall(pygame.sprite.Sprite):

    def __init__(self, pos_w):
        super().__init__(all_sprites)
        self.add(invisibles)
        self.image = load_image('in_wall.png')
        self.rect = self.image.get_rect()
        self.rect.x = pos_w[0]
        self.rect.y = pos_w[1]


class Floor(pygame.sprite.Sprite):

    def __init__(self, pos_w):
        super().__init__(all_sprites)
        self.add(floors)
        self.image = load_image('floor.png')
        self.rect = self.image.get_rect()
        self.rect.x = pos_w[0]
        self.rect.y = pos_w[1]


class Hero(pygame.sprite.Sprite):
    def __init__(self, pos):
        super().__init__(all_sprites)
        self.add(hero_sprite)
        self.image = load_image('hero.png')
        self.rect = pygame.Rect(pos, (50, 50))


class Destination(pygame.sprite.Sprite):

    def __init__(self, pos_w):
        super().__init__(all_sprites)
        self.add(destinations)
        self.image = load_image('destination.png')
        self.rect = self.image.get_rect()
        self.rect.x = pos_w[0]
        self.rect.y = pos_w[1]


class Mag_stone(pygame.sprite.Sprite):

    def __init__(self, pos_w):
        super().__init__(all_sprites)
        self.add(mag_stones)
        self.image = load_image('magick_stone.png')
        self.rect = self.image.get_rect()
        self.rect.x = pos_w[0]
        self.rect.y = pos_w[1]


class Level_complete_event(pygame.sprite.Sprite):
    image_right = None
    image_left = None

    def __init__(self, group, size):
        super().__init__(group)
        if Level_complete_event.image_right is None:
            Level_complete_event.image_right = load_image("level_completed.png")
            Level_complete_event.image_left = pygame.transform.flip(Level_complete_event.image_right, True, False)
        self.width, self.height = size
        self.image = Level_complete_event.image_right
        self.rect = self.image.get_rect()
        self.vx = 10
        self.ticks = 0
        self.rect.left = - 600

    def update(self):
        if self.rect.left + self.rect.width > self.width:
            self.vx = 0
        self.rect.left = self.rect.left + self.vx
        self.ticks = 0


def render_level():
    need_map = Level_construct(map_of_level).map_return()
    for i in range(len(need_map)):
        for j in range(len(need_map[i])):
            if need_map[i][j] != 9:
                place = [300 + j * TILE_SIZE, 300 + i * TILE_SIZE]
                Floor(place)
            if need_map[i][j] == 1:
                place = [300 + j * TILE_SIZE, 300 + i * TILE_SIZE]
                Wall(place)
            if need_map[i][j] == 2:
                place = [300 + j * TILE_SIZE, 300 + i * TILE_SIZE]
                Destination(place)
            if need_map[i][j] == 9:
                place = [300 + j * TILE_SIZE, 300 + i * TILE_SIZE]
                Invisibles_wall(place)


def place_detection(number_magick_stone, obj_name):
    need_map = Level_construct(map_of_level).map_return()
    if obj_name == 'magick_stone':
        fun_number = 0
        for i in range(len(need_map)):
            for j in range(len(need_map[i])):
                if need_map[i][j] == 3:
                    fun_number += 1
                    if fun_number == number_magick_stone:
                        place = [300 + j * TILE_SIZE, 300 + i * TILE_SIZE]
                        return place
    elif obj_name == 'hero':
        for i in range(len(need_map)):
            for j in range(len(need_map[i])):
                if need_map[i][j] == 4:
                    place = [300 + j * TILE_SIZE, 300 + i * TILE_SIZE]
                    return place


mm = Mag_stone(place_detection(1, 'magick_stone'))
if len(destinations) == 2 or len(destinations) == 3:
    mm2 = Mag_stone(place_detection(2, 'magick_stone'))
if len(destinations) == 3:
    mm3 = Mag_stone(place_detection(3, 'magick_stone'))
hero = Hero(place_detection(3, 'hero'))


def lvl_com():
    com = True
    if pygame.sprite.spritecollideany(mm, destinations):
        _ = Level_complete_event(all_sprites, (1920, 1080))
        while com:
            clock.tick(30)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    com = False
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        pygame.quit()
                        quit()
            all_sprites.draw(screen)
            all_sprites.update()
            pygame.display.flip()


def magick_stone_move(nam_mag_st, direction):
    if direction == 'right':
        nam_mag_st.rect.left += speed
        if pygame.sprite.spritecollideany(nam_mag_st, walls) or pygame.sprite.spritecollideany(nam_mag_st, invisibles) \
                or (pygame.sprite.collide_rect(mm, mm2) if 'mm2' in globals() else False)\
                or (pygame.sprite.collide_rect(mm, mm3) if 'mm3' in globals() else False) \
                or (pygame.sprite.collide_rect(mm2, mm3) if ('mm2' in globals() and 'mm3' in globals()) else False):
            nam_mag_st.rect.left -= speed
            hero.rect.left -= speed
    if direction == 'up':
        nam_mag_st.rect.top -= speed
        if pygame.sprite.spritecollideany(nam_mag_st, walls) or pygame.sprite.spritecollideany(nam_mag_st, invisibles) \
                or (pygame.sprite.collide_rect(mm, mm2) if 'mm2' in globals() else False) \
                or (pygame.sprite.collide_rect(mm, mm3) if 'mm3' in globals() else False) \
                or (pygame.sprite.collide_rect(mm2, mm3) if ('mm2' in globals() and 'mm3' in globals()) else False):
            nam_mag_st.rect.top += speed
            hero.rect.top += speed
    if direction == 'left':
        nam_mag_st.rect.left -= speed
        if pygame.sprite.spritecollideany(nam_mag_st, walls) or pygame.sprite.spritecollideany(nam_mag_st, invisibles) \
                or (pygame.sprite.collide_rect(mm, mm2) if 'mm2' in globals() else False) \
                or (pygame.sprite.collide_rect(mm, mm3) if 'mm3' in globals() else False) \
                or (pygame.sprite.collide_rect(mm2, mm3) if ('mm2' in globals() and 'mm3' in globals()) else False):
            nam_mag_st.rect.left += speed
            hero.rect.left += speed
    if direction == 'down':
        nam_mag_st.rect.top += speed
        if pygame.sprite.spritecollideany(nam_mag_st, walls) or pygame.sprite.spritecollideany(nam_mag_st, invisibles) \
                or (pygame.sprite.collide_rect(mm, mm2) if 'mm2' in globals() else False) \
                or (pygame.sprite.collide_rect(mm, mm3) if 'mm3' in globals() else False) \
                or (pygame.sprite.collide_rect(mm2, mm3) if ('mm2' in globals() and 'mm3' in globals()) else False):
            nam_mag_st.rect.top -= speed
            hero.rect.top -= speed


def level_win(count_destination):
    if count_destination == 1:
        if pygame.sprite.spritecollideany(mm, destinations):
            lvl_com()
    elif count_destination == 2:
        if pygame.sprite.spritecollideany(mm, destinations) and pygame.sprite.spritecollideany(mm2, destinations):
            lvl_com()
    else:
        if pygame.sprite.spritecollideany(mm, destinations) and pygame.sprite.spritecollideany(mm2, destinations) and\
                pygame.sprite.spritecollideany(mm3, destinations):
            lvl_com()


def game():
    global mm, mm2, mm3, hero
    render_level()
    mm = Mag_stone(place_detection(1, 'magick_stone'))
    if len(destinations) == 2 or len(destinations) == 3:
        mm2 = Mag_stone(place_detection(2, 'magick_stone'))
    if len(destinations) == 3:
        mm3 = Mag_stone(place_detection(3, 'magick_stone'))
    hero = Hero(place_detection(3, 'hero'))
    run = True
    while run:
        clock.tick(60)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False

            key = pygame.key.get_pressed()

            if key[pygame.K_DOWN] and hero.rect.top < 1080 - 50 - 5:
                hero.rect.top += speed
                if pygame.sprite.spritecollideany(mm, hero_sprite):
                    magick_stone_move(mm, 'down')
                if 'mm2' in globals():
                    if pygame.sprite.spritecollideany(mm2, hero_sprite):
                        magick_stone_move(mm2, 'down')
                if 'mm3' in globals():
                    if pygame.sprite.spritecollideany(mm3, hero_sprite):
                        magick_stone_move(mm3, 'down')
                if pygame.sprite.spritecollideany(hero, walls):
                    hero.rect.top -= speed

            if key[pygame.K_UP] and hero.rect.top > 25:
                hero.rect.top -= speed
                if pygame.sprite.spritecollideany(mm, hero_sprite):
                    magick_stone_move(mm, 'up')
                if 'mm2' in globals():
                    if pygame.sprite.spritecollideany(mm2, hero_sprite):
                        magick_stone_move(mm2, 'up')
                if 'mm3' in globals():
                    if pygame.sprite.spritecollideany(mm3, hero_sprite):
                        magick_stone_move(mm3, 'up')
                if pygame.sprite.spritecollideany(hero, walls):
                    hero.rect.top += speed

            if key[pygame.K_RIGHT] and hero.rect.left < 1920 - 50 - 5:
                hero.rect.left += speed
                if pygame.sprite.spritecollideany(mm, hero_sprite):
                    magick_stone_move(mm, 'right')
                if 'mm2' in globals():
                    if pygame.sprite.spritecollideany(mm2, hero_sprite):
                        magick_stone_move(mm2, 'right')
                if 'mm3' in globals():
                    if pygame.sprite.spritecollideany(mm3, hero_sprite):
                        magick_stone_move(mm3, 'right')
                if pygame.sprite.spritecollideany(hero, walls):
                    hero.rect.left -= speed

            if key[pygame.K_LEFT] and hero.rect.left > 25:
                hero.rect.left -= speed
                if pygame.sprite.spritecollideany(mm, hero_sprite):
                    magick_stone_move(mm, 'left')
                if 'mm2' in globals():
                    if pygame.sprite.spritecollideany(mm2, hero_sprite):
                        magick_stone_move(mm2, 'left')
                if 'mm3' in globals():
                    if pygame.sprite.spritecollideany(mm3, hero_sprite):
                        magick_stone_move(mm3, 'left')
                if pygame.sprite.spritecollideany(hero, walls):
                    hero.rect.left += speed

        level_win(len(destinations))

        screen.blit(game_bg, (0, 0))
        all_sprites.draw(screen)
        all_sprites.update()
        pygame.display.flip()


def draw(screen1, font_size, font_sh, font_text, text_y, color):
    font = pygame.font.Font(font_sh, font_size)
    text = font.render(font_text, True, color)
    text_x = width // 2 - text.get_width() // 2
    screen1.blit(text, (text_x, text_y))


def rule_window():
    manager1 = pygame_gui.UIManager((1920, 1080))
    rules = ['Правила игры предельно просты:',
             '1)Игроку необходимо довести магические',
             'кристаллы до обозначенных мест уровня.',
             '2)Игрок одновременно может двигать только',
             'один магический кристал, толкая вперёд.']

    ok_btn = pygame_gui.elements.UIButton(
        relative_rect=pygame.Rect((760, 560), (400, 50)),
        text='Ok',
        manager=manager1
    )

    run = True
    while run:
        fps = clock.tick(60) / 1000.0
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            if event.type == pygame.USEREVENT:
                if event.user_type == pygame_gui.UI_BUTTON_PRESSED:
                    if event.ui_element == ok_btn:
                        menu()
            manager1.process_events(event)
        manager1.update(fps)
        screen.blit(menu_bg, (0, 0))
        manager1.draw_ui(screen)
        for i in range(len(rules)):
            draw(screen, 50, None, rules[i], 300 + 50 * i, (0, 255, 255))
        pygame.display.update()


def level_selected():
    global map_of_level

    manager1 = pygame_gui.UIManager((1920, 1080))

    level1_btn = pygame_gui.elements.UIButton(
        relative_rect=pygame.Rect((760, 300), (400, 50)),
        text='1ый уровень',
        manager=manager1
    )
    level2_btn = pygame_gui.elements.UIButton(
        relative_rect=pygame.Rect((760, 400), (400, 50)),
        text='2ый уровень',
        manager=manager1
    )
    level3_btn = pygame_gui.elements.UIButton(
        relative_rect=pygame.Rect((760, 500), (400, 50)),
        text='3ый уровень',
        manager=manager1
    )
    level4_btn = pygame_gui.elements.UIButton(
        relative_rect=pygame.Rect((760, 600), (400, 50)),
        text='4ый уровень',
        manager=manager1
    )
    level5_btn = pygame_gui.elements.UIButton(
        relative_rect=pygame.Rect((760, 700), (400, 50)),
        text='5ый уровень(сложный)',
        manager=manager1
    )
    back_menu_btn = pygame_gui.elements.UIButton(
        relative_rect=pygame.Rect((0, 0), (200, 50)),
        text='<-- обратно в меню',
        manager=manager1
    )

    run = True
    while run:
        fps = clock.tick(60) / 1000.0
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            if event.type == pygame.USEREVENT:
                if event.user_type == pygame_gui.UI_BUTTON_PRESSED:
                    if event.ui_element == level1_btn:
                        map_of_level = 'map1.txt'
                        game()
                    if event.ui_element == level2_btn:
                        map_of_level = 'map2.txt'
                        game()
                    if event.ui_element == level3_btn:
                        map_of_level = 'map3.txt'
                        game()
                    if event.ui_element == level4_btn:
                        map_of_level = 'map4.txt'
                        game()
                    if event.ui_element == level5_btn:
                        map_of_level = 'map5.txt'
                        game()
                    if event.ui_element == back_menu_btn:
                        menu()
            manager1.process_events(event)
        manager1.update(fps)
        screen.blit(menu_bg, (0, 0))
        manager1.draw_ui(screen)
        draw(screen, 120, None, 'Выберите уровень', 150, (128, 0, 128))
        pygame.display.update()

    return map_of_level


def menu():

    manager = pygame_gui.UIManager((1920, 1080))

    level_select_btn = pygame_gui.elements.UIButton(
        relative_rect=pygame.Rect((710, 600), (500, 70)),
        text='Выбрать уровень',
        manager=manager
    )
    rule_btn = pygame_gui.elements.UIButton(
        relative_rect=pygame.Rect((710, 700), (500, 70)),
        text='Правила',
        manager=manager
    )

    exit_btn = pygame_gui.elements.UIButton(
        relative_rect=pygame.Rect((710, 800), (500, 70)),
        text='Выйти',
        manager=manager
    )

    run = True
    while run:
        fps = clock.tick(60) / 1000.0
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()
            if event.type == pygame.USEREVENT:
                if event.user_type == pygame_gui.UI_BUTTON_PRESSED:
                    if event.ui_element == level_select_btn:
                        level_selected()
                    if event.ui_element == rule_btn:
                        rule_window()
                    if event.ui_element == exit_btn:
                        pygame.quit()
                        quit()

            manager.process_events(event)
        manager.update(fps)
        screen.blit(menu_bg, (0, 0))
        manager.draw_ui(screen)
        draw(screen, 150, "data1\\Pixels.ttf", "Dungeon Quest!", 150, (128, 0, 128))
        pygame.display.update()


menu()

pygame.quit()
